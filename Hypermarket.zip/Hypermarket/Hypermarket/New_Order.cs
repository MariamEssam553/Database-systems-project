﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Hypermarket
{
    public partial class New_Order : Form
    {
        Controller controllerObj;
        int Cashier_ID;
        int Cust_ID;
        int ItemsN;
        public New_Order(Controller controllerObj, int Cashier_ID, decimal Cust_ID)
        {
            InitializeComponent();
            this.controllerObj = controllerObj;
            this.Cashier_ID = Cashier_ID;
            this.Cust_ID = Int32.Parse(Cust_ID.ToString());
            Receipt.Columns.Add("P ID", "P ID");
            Receipt.Columns.Add("Name", "Name");
            Receipt.Columns.Add("Rate", "Rate");
            Receipt.Columns.Add("Quantity", "Quantity");
            Receipt.Columns.Add("Value", "Value");
            Receipt.Refresh();
            ItemsN = 0;
            Total_Price.Text = "0";
            CID.Text = Cust_ID.ToString();
        }

        private void Add_Click(object sender, EventArgs e)
        {
            if (controllerObj.ItemExist(P_ID.Value) == 0)
            {
                MessageBox.Show("Item Does not Exist, Check Product ID!");
                return;
            }
            if (ItemsN > 0)
            { 
                for (int i = 0; i < ItemsN; i++)
                {
                    if (Receipt.Rows[i].Cells[0].Value.ToString() == P_ID.Value.ToString())
                    {
                        MessageBox.Show("Item Already Exists in Receipt!");
                        return;
                    }
                }
            }
            DataTable dt = controllerObj.getItemInfo(P_ID.Value);
            string pid = dt.Rows[0][0].ToString();
            string name = dt.Rows[0][1].ToString();
            string rate = dt.Rows[0][2].ToString();
            string quantity = N_Items.Value.ToString();
            string value = (Int32.Parse(rate) * Int32.Parse(quantity)).ToString();
            Receipt.Rows.Add(pid, name, rate, quantity, value);
            Total_Price.Text = (Int32.Parse(Total_Price.Text)+ Int32.Parse(value)).ToString();
            ItemsN++;
        }

        private void Remove_Click(object sender, EventArgs e)
        {
            if (ItemsN == 0)
            {
                MessageBox.Show("No Items to remove!");
                return;
            }
            if (Receipt.SelectedRows.Count != 1)
            {
                MessageBox.Show("Select one row at a time!");
                return;
            }
            int index = Receipt.SelectedRows[0].Index;
            string value = Receipt.Rows[index].Cells[3].Value.ToString();
            Total_Price.Text = (Int32.Parse(Total_Price.Text) - Int32.Parse(value)).ToString();
            Receipt.Rows.RemoveAt(index);
            ItemsN--;
        }

        private void Confirm_Click(object sender, EventArgs e)
        {
            if (ItemsN == 0)
            {
                MessageBox.Show("Add Items to the Receipt!");
                return;
            }

            controllerObj.ApplyBuys(Cashier_ID, Cust_ID);
            for (int i = 0; i < ItemsN; i++)
            {
                controllerObj.ApplyBought(
                    Receipt.Rows[i].Cells[0].Value.ToString(),
                    Cust_ID, Cashier_ID, 
                    Receipt.Rows[i].Cells[3].Value.ToString());
            }
            MessageBox.Show("Transaction Complete! Total Price is " 
                + Total_Price.Text +" Pounds!");
            New_Order.ActiveForm.Close();
        }

        private void New_Order_Load(object sender, EventArgs e)
        {

        }
    }
}
