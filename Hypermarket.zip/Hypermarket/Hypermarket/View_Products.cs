﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hypermarket
{
    public partial class View_Products : Form
    {
        Controller obj;
        public View_Products()
        {
            InitializeComponent();
            obj = new Controller();
            DataTable dt = obj.GetProducts();
            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();
            dataGridView1.ReadOnly = true;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
