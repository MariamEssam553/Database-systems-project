﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Hypermarket
{
    public partial class New_Customer : Form
    {
        Controller controllerObj;
        public New_Customer(Controller controller)
        {
            InitializeComponent();
            controllerObj = controller;
            Gender.SelectedIndex = 0;
            Gender.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void Insert_Customer_Click(object sender, EventArgs e)
        {
            if (FName.Text == "" || LName.Text == "" || PhoneNumber.Text == "" || Email.Text == ""
                || Street.Text == "" || City.Text == "" || Gender.Text == "")
                MessageBox.Show("Enter all Fields!");
            else
            {
                if (controllerObj.CustIDExist(ID.Value) != 0)
                    MessageBox.Show("ID Already Exists");
                else
                {
                    int result = controllerObj.InsertCustomer(ID.Value, FName.Text, LName.Text, PhoneNumber.Text,
                        Email.Text, Gender.Text, Age.Value, Street.Text, BNum.Text, ApNum.Value, City.Text);
                    if (result == 0)
                        MessageBox.Show("Customer Insertion Failed!");
                    else
                        MessageBox.Show("Customer Inserted Successfully!");
                }
            }
        }

        private void New_Customer_Load(object sender, EventArgs e)
        {

        }
    }
}
