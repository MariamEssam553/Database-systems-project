﻿namespace Hypermarket
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.viewEmpTypes = new System.Windows.Forms.Button();
            this.empId = new System.Windows.Forms.TextBox();
            this.empFname = new System.Windows.Forms.TextBox();
            this.empLname = new System.Windows.Forms.TextBox();
            this.empPhone = new System.Windows.Forms.TextBox();
            this.empEmail = new System.Windows.Forms.TextBox();
            this.empSalary = new System.Windows.Forms.TextBox();
            this.empStartDate = new System.Windows.Forms.TextBox();
            this.empAge = new System.Windows.Forms.TextBox();
            this.empStreet = new System.Windows.Forms.TextBox();
            this.empBuilding = new System.Windows.Forms.TextBox();
            this.empAppartment = new System.Windows.Forms.TextBox();
            this.empCity = new System.Windows.Forms.TextBox();
            this.empTitle = new System.Windows.Forms.TextBox();
            this.empPassword = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.empGender = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.insertEmployee = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.empHours = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.updSalary = new System.Windows.Forms.TextBox();
            this.updAge = new System.Windows.Forms.TextBox();
            this.updHours = new System.Windows.Forms.TextBox();
            this.updateEmp = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.refresh = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(30, 289);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(740, 127);
            this.dataGridView1.TabIndex = 0;
            // 
            // viewEmpTypes
            // 
            this.viewEmpTypes.Location = new System.Drawing.Point(12, 12);
            this.viewEmpTypes.Name = "viewEmpTypes";
            this.viewEmpTypes.Size = new System.Drawing.Size(101, 48);
            this.viewEmpTypes.TabIndex = 1;
            this.viewEmpTypes.Text = "View Employee Types";
            this.viewEmpTypes.UseVisualStyleBackColor = true;
            this.viewEmpTypes.Click += new System.EventHandler(this.viewEmpTypes_Click);
            // 
            // empId
            // 
            this.empId.Location = new System.Drawing.Point(465, 31);
            this.empId.Name = "empId";
            this.empId.Size = new System.Drawing.Size(100, 20);
            this.empId.TabIndex = 2;
            // 
            // empFname
            // 
            this.empFname.Location = new System.Drawing.Point(465, 57);
            this.empFname.Name = "empFname";
            this.empFname.Size = new System.Drawing.Size(100, 20);
            this.empFname.TabIndex = 3;
            // 
            // empLname
            // 
            this.empLname.Location = new System.Drawing.Point(465, 83);
            this.empLname.Name = "empLname";
            this.empLname.Size = new System.Drawing.Size(100, 20);
            this.empLname.TabIndex = 4;
            // 
            // empPhone
            // 
            this.empPhone.Location = new System.Drawing.Point(465, 109);
            this.empPhone.Name = "empPhone";
            this.empPhone.Size = new System.Drawing.Size(100, 20);
            this.empPhone.TabIndex = 5;
            // 
            // empEmail
            // 
            this.empEmail.Location = new System.Drawing.Point(465, 135);
            this.empEmail.Name = "empEmail";
            this.empEmail.Size = new System.Drawing.Size(100, 20);
            this.empEmail.TabIndex = 6;
            // 
            // empSalary
            // 
            this.empSalary.Location = new System.Drawing.Point(465, 161);
            this.empSalary.Name = "empSalary";
            this.empSalary.Size = new System.Drawing.Size(100, 20);
            this.empSalary.TabIndex = 7;
            // 
            // empStartDate
            // 
            this.empStartDate.Location = new System.Drawing.Point(688, 31);
            this.empStartDate.Name = "empStartDate";
            this.empStartDate.Size = new System.Drawing.Size(100, 20);
            this.empStartDate.TabIndex = 9;
            // 
            // empAge
            // 
            this.empAge.Location = new System.Drawing.Point(688, 57);
            this.empAge.Name = "empAge";
            this.empAge.Size = new System.Drawing.Size(100, 20);
            this.empAge.TabIndex = 10;
            // 
            // empStreet
            // 
            this.empStreet.Location = new System.Drawing.Point(688, 83);
            this.empStreet.Name = "empStreet";
            this.empStreet.Size = new System.Drawing.Size(100, 20);
            this.empStreet.TabIndex = 11;
            // 
            // empBuilding
            // 
            this.empBuilding.Location = new System.Drawing.Point(688, 109);
            this.empBuilding.Name = "empBuilding";
            this.empBuilding.Size = new System.Drawing.Size(100, 20);
            this.empBuilding.TabIndex = 12;
            // 
            // empAppartment
            // 
            this.empAppartment.Location = new System.Drawing.Point(688, 135);
            this.empAppartment.Name = "empAppartment";
            this.empAppartment.Size = new System.Drawing.Size(100, 20);
            this.empAppartment.TabIndex = 13;
            // 
            // empCity
            // 
            this.empCity.Location = new System.Drawing.Point(688, 161);
            this.empCity.Name = "empCity";
            this.empCity.Size = new System.Drawing.Size(100, 20);
            this.empCity.TabIndex = 14;
            // 
            // empTitle
            // 
            this.empTitle.Location = new System.Drawing.Point(688, 187);
            this.empTitle.Name = "empTitle";
            this.empTitle.Size = new System.Drawing.Size(100, 20);
            this.empTitle.TabIndex = 15;
            // 
            // empPassword
            // 
            this.empPassword.Location = new System.Drawing.Point(688, 213);
            this.empPassword.Name = "empPassword";
            this.empPassword.Size = new System.Drawing.Size(100, 20);
            this.empPassword.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(372, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(18, 13);
            this.label1.TabIndex = 17;
            this.label1.Text = "ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(372, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 18;
            this.label2.Text = "First Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(372, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 19;
            this.label3.Text = "Last Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(372, 116);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 13);
            this.label4.TabIndex = 20;
            this.label4.Text = "Phone Number";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(372, 142);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(32, 13);
            this.label5.TabIndex = 21;
            this.label5.Text = "Email";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(372, 168);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(36, 13);
            this.label6.TabIndex = 22;
            this.label6.Text = "Salary";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(372, 194);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 13);
            this.label7.TabIndex = 23;
            this.label7.Text = "Gender";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(599, 34);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 13);
            this.label8.TabIndex = 24;
            this.label8.Text = "Start Date";
            // 
            // empGender
            // 
            this.empGender.FormattingEnabled = true;
            this.empGender.Items.AddRange(new object[] {
            "M",
            "F"});
            this.empGender.Location = new System.Drawing.Point(465, 191);
            this.empGender.Name = "empGender";
            this.empGender.Size = new System.Drawing.Size(40, 21);
            this.empGender.TabIndex = 25;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(607, 60);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(26, 13);
            this.label9.TabIndex = 26;
            this.label9.Text = "Age";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(607, 86);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(35, 13);
            this.label10.TabIndex = 27;
            this.label10.Text = "Street";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(589, 112);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(84, 13);
            this.label11.TabIndex = 28;
            this.label11.Text = "Building Number";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(581, 138);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(101, 13);
            this.label12.TabIndex = 29;
            this.label12.Text = "Appartment Number";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(607, 164);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(24, 13);
            this.label13.TabIndex = 30;
            this.label13.Text = "City";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(607, 187);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(27, 13);
            this.label14.TabIndex = 31;
            this.label14.Text = "Title";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(607, 216);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(53, 13);
            this.label15.TabIndex = 32;
            this.label15.Text = "Password";
            // 
            // insertEmployee
            // 
            this.insertEmployee.Location = new System.Drawing.Point(445, 235);
            this.insertEmployee.Name = "insertEmployee";
            this.insertEmployee.Size = new System.Drawing.Size(120, 34);
            this.insertEmployee.TabIndex = 33;
            this.insertEmployee.Text = "Insert Employee";
            this.insertEmployee.UseVisualStyleBackColor = true;
            this.insertEmployee.Click += new System.EventHandler(this.insertEmployee_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(599, 239);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(78, 13);
            this.label16.TabIndex = 34;
            this.label16.Text = "Working Hours";
            // 
            // empHours
            // 
            this.empHours.Location = new System.Drawing.Point(688, 239);
            this.empHours.Name = "empHours";
            this.empHours.Size = new System.Drawing.Size(100, 20);
            this.empHours.TabIndex = 35;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(27, 116);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(18, 13);
            this.label17.TabIndex = 36;
            this.label17.Text = "ID";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(51, 113);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(73, 21);
            this.comboBox1.TabIndex = 37;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(27, 151);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(36, 13);
            this.label18.TabIndex = 38;
            this.label18.Text = "Salary";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(27, 187);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(26, 13);
            this.label19.TabIndex = 39;
            this.label19.Text = "Age";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(27, 220);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(78, 13);
            this.label20.TabIndex = 40;
            this.label20.Text = "Working Hours";
            // 
            // updSalary
            // 
            this.updSalary.Location = new System.Drawing.Point(79, 148);
            this.updSalary.Name = "updSalary";
            this.updSalary.Size = new System.Drawing.Size(100, 20);
            this.updSalary.TabIndex = 41;
            // 
            // updAge
            // 
            this.updAge.Location = new System.Drawing.Point(79, 184);
            this.updAge.Name = "updAge";
            this.updAge.Size = new System.Drawing.Size(100, 20);
            this.updAge.TabIndex = 42;
            // 
            // updHours
            // 
            this.updHours.Location = new System.Drawing.Point(111, 213);
            this.updHours.Name = "updHours";
            this.updHours.Size = new System.Drawing.Size(100, 20);
            this.updHours.TabIndex = 43;
            // 
            // updateEmp
            // 
            this.updateEmp.Location = new System.Drawing.Point(30, 246);
            this.updateEmp.Name = "updateEmp";
            this.updateEmp.Size = new System.Drawing.Size(181, 23);
            this.updateEmp.TabIndex = 44;
            this.updateEmp.Text = "Update Employee";
            this.updateEmp.UseVisualStyleBackColor = true;
            this.updateEmp.Click += new System.EventHandler(this.updateEmp_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(154, 111);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(132, 23);
            this.button1.TabIndex = 45;
            this.button1.Text = "Delete Employee";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Inventory department",
            "It department",
            "Procurement department",
            "Sales department",
            "Cashiers"});
            this.comboBox2.Location = new System.Drawing.Point(232, 60);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 46;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(133, 64);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(93, 13);
            this.label21.TabIndex = 47;
            this.label21.Text = "Department Name";
            // 
            // refresh
            // 
            this.refresh.Location = new System.Drawing.Point(136, 86);
            this.refresh.Name = "refresh";
            this.refresh.Size = new System.Drawing.Size(217, 23);
            this.refresh.TabIndex = 48;
            this.refresh.Text = "Refresh";
            this.refresh.UseVisualStyleBackColor = true;
            this.refresh.Click += new System.EventHandler(this.refresh_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.refresh);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.updateEmp);
            this.Controls.Add(this.updHours);
            this.Controls.Add(this.updAge);
            this.Controls.Add(this.updSalary);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.empHours);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.insertEmployee);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.empGender);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.empPassword);
            this.Controls.Add(this.empTitle);
            this.Controls.Add(this.empCity);
            this.Controls.Add(this.empAppartment);
            this.Controls.Add(this.empBuilding);
            this.Controls.Add(this.empStreet);
            this.Controls.Add(this.empAge);
            this.Controls.Add(this.empStartDate);
            this.Controls.Add(this.empSalary);
            this.Controls.Add(this.empEmail);
            this.Controls.Add(this.empPhone);
            this.Controls.Add(this.empLname);
            this.Controls.Add(this.empFname);
            this.Controls.Add(this.empId);
            this.Controls.Add(this.viewEmpTypes);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button viewEmpTypes;
        private System.Windows.Forms.TextBox empId;
        private System.Windows.Forms.TextBox empFname;
        private System.Windows.Forms.TextBox empLname;
        private System.Windows.Forms.TextBox empPhone;
        private System.Windows.Forms.TextBox empEmail;
        private System.Windows.Forms.TextBox empSalary;
        private System.Windows.Forms.TextBox empStartDate;
        private System.Windows.Forms.TextBox empAge;
        private System.Windows.Forms.TextBox empStreet;
        private System.Windows.Forms.TextBox empBuilding;
        private System.Windows.Forms.TextBox empAppartment;
        private System.Windows.Forms.TextBox empCity;
        private System.Windows.Forms.TextBox empTitle;
        private System.Windows.Forms.TextBox empPassword;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox empGender;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button insertEmployee;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox empHours;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox updSalary;
        private System.Windows.Forms.TextBox updAge;
        private System.Windows.Forms.TextBox updHours;
        private System.Windows.Forms.Button updateEmp;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button refresh;
    }
}

