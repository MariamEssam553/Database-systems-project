﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hypermarket
{
    public partial class Profit_per_day : Form
    {
        Controller obj;
        public Profit_per_day()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            obj = new Controller();
            int result = obj.ProfitPerDay(dateTimePicker1.Value.ToShortDateString());
            dataGridView1.DataSource = result;
            dataGridView1.Refresh();
        }
    }
}
