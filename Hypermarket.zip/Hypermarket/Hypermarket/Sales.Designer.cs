﻿
namespace Hypermarket
{
    partial class Sales
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.profit_label = new System.Windows.Forms.Label();
            this.LName = new System.Windows.Forms.Label();
            this.SName = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.P_textBox = new System.Windows.Forms.TextBox();
            this.P_label = new System.Windows.Forms.Label();
            this.most_button = new System.Windows.Forms.Button();
            this.Profit_button = new System.Windows.Forms.Button();
            this.Price_textBox = new System.Windows.Forms.TextBox();
            this.Price_label = new System.Windows.Forms.Label();
            this.Code_textBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Update_button = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // profit_label
            // 
            this.profit_label.AutoSize = true;
            this.profit_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profit_label.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.profit_label.Location = new System.Drawing.Point(619, 194);
            this.profit_label.Name = "profit_label";
            this.profit_label.Size = new System.Drawing.Size(67, 18);
            this.profit_label.TabIndex = 37;
            this.profit_label.Text = "Number";
            // 
            // LName
            // 
            this.LName.AutoSize = true;
            this.LName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LName.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.LName.Location = new System.Drawing.Point(611, 523);
            this.LName.Name = "LName";
            this.LName.Size = new System.Drawing.Size(61, 18);
            this.LName.TabIndex = 36;
            this.LName.Text = "LName";
            // 
            // SName
            // 
            this.SName.AutoSize = true;
            this.SName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SName.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.SName.Location = new System.Drawing.Point(610, 457);
            this.SName.Name = "SName";
            this.SName.Size = new System.Drawing.Size(63, 18);
            this.SName.TabIndex = 35;
            this.SName.Text = "SName";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(497, 523);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 17);
            this.label3.TabIndex = 34;
            this.label3.Text = "Least Sold";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(497, 457);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 17);
            this.label2.TabIndex = 33;
            this.label2.Text = "Most Sold";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(46, 381);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(401, 208);
            this.dataGridView1.TabIndex = 32;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(424, 188);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(157, 28);
            this.button1.TabIndex = 31;
            this.button1.Text = "Product Profit/Loss";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // P_textBox
            // 
            this.P_textBox.Location = new System.Drawing.Point(211, 191);
            this.P_textBox.Name = "P_textBox";
            this.P_textBox.Size = new System.Drawing.Size(167, 22);
            this.P_textBox.TabIndex = 30;
            // 
            // P_label
            // 
            this.P_label.AutoSize = true;
            this.P_label.Location = new System.Drawing.Point(60, 194);
            this.P_label.Name = "P_label";
            this.P_label.Size = new System.Drawing.Size(25, 17);
            this.P_label.TabIndex = 29;
            this.P_label.Text = "P#";
            // 
            // most_button
            // 
            this.most_button.Location = new System.Drawing.Point(483, 399);
            this.most_button.Name = "most_button";
            this.most_button.Size = new System.Drawing.Size(194, 32);
            this.most_button.TabIndex = 28;
            this.most_button.Text = "Most/Least sold products";
            this.most_button.UseVisualStyleBackColor = true;
            this.most_button.Click += new System.EventHandler(this.most_button_Click);
            // 
            // Profit_button
            // 
            this.Profit_button.Location = new System.Drawing.Point(483, 289);
            this.Profit_button.Name = "Profit_button";
            this.Profit_button.Size = new System.Drawing.Size(194, 33);
            this.Profit_button.TabIndex = 27;
            this.Profit_button.Text = "Net Profit/Day";
            this.Profit_button.UseVisualStyleBackColor = true;
            this.Profit_button.Click += new System.EventHandler(this.Profit_button_Click);
            // 
            // Price_textBox
            // 
            this.Price_textBox.Location = new System.Drawing.Point(209, 90);
            this.Price_textBox.Name = "Price_textBox";
            this.Price_textBox.Size = new System.Drawing.Size(169, 22);
            this.Price_textBox.TabIndex = 26;
            // 
            // Price_label
            // 
            this.Price_label.AutoSize = true;
            this.Price_label.Location = new System.Drawing.Point(60, 93);
            this.Price_label.Name = "Price_label";
            this.Price_label.Size = new System.Drawing.Size(71, 17);
            this.Price_label.TabIndex = 25;
            this.Price_label.Text = "New Price";
            // 
            // Code_textBox
            // 
            this.Code_textBox.Location = new System.Drawing.Point(211, 35);
            this.Code_textBox.Name = "Code_textBox";
            this.Code_textBox.Size = new System.Drawing.Size(167, 22);
            this.Code_textBox.TabIndex = 24;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(60, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 17);
            this.label1.TabIndex = 23;
            this.label1.Text = "Product Code";
            // 
            // Update_button
            // 
            this.Update_button.Location = new System.Drawing.Point(520, 85);
            this.Update_button.Name = "Update_button";
            this.Update_button.Size = new System.Drawing.Size(157, 33);
            this.Update_button.TabIndex = 22;
            this.Update_button.Text = "Update";
            this.Update_button.UseVisualStyleBackColor = true;
            this.Update_button.Click += new System.EventHandler(this.Update_button_Click);
            // 
            // Sales
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(732, 625);
            this.Controls.Add(this.profit_label);
            this.Controls.Add(this.LName);
            this.Controls.Add(this.SName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.P_textBox);
            this.Controls.Add(this.P_label);
            this.Controls.Add(this.most_button);
            this.Controls.Add(this.Profit_button);
            this.Controls.Add(this.Price_textBox);
            this.Controls.Add(this.Price_label);
            this.Controls.Add(this.Code_textBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Update_button);
            this.Name = "Sales";
            this.Text = "Sales";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label profit_label;
        private System.Windows.Forms.Label LName;
        private System.Windows.Forms.Label SName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox P_textBox;
        private System.Windows.Forms.Label P_label;
        private System.Windows.Forms.Button most_button;
        private System.Windows.Forms.Button Profit_button;
        private System.Windows.Forms.TextBox Price_textBox;
        private System.Windows.Forms.Label Price_label;
        private System.Windows.Forms.TextBox Code_textBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Update_button;
    }
}