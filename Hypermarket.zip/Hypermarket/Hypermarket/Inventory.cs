﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hypermarket
{
    public partial class Inventory : Form
    {
        Controller obj;
        public Inventory()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            obj = new Controller();
            int n = obj.Delete_inventory(Convert.ToInt32(textBox2.Text), Convert.ToInt32(textBox1.Text));
            if (n != 0)
            {
                MessageBox.Show("Updated sucessfully");
            }
            else
            {
                MessageBox.Show("Error!Check P#");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            obj = new Controller();
            obj.update_replenish(Convert.ToInt32(textBox4.Text), Convert.ToInt32(textBox3.Text), Convert.ToInt32(textBox5.Text));
            int n = obj.Add_inventory(Convert.ToInt32(textBox3.Text), Convert.ToInt32(textBox4.Text));
            if (n != 0)
            {
                MessageBox.Show("Added sucessfully");
            }
            else
            {
                MessageBox.Show("Error!Check P#");
            }
        }

        private void View_button_Click(object sender, EventArgs e)
        {
            Inventory_Items n = new Inventory_Items();
            n.Show();
        }
    }
}
