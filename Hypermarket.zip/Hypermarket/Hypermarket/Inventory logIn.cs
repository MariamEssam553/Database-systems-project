﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hypermarket
{
    public partial class Inventory_logIn : Form
    {
        Controller obj;
        public Inventory_logIn()
        {
            InitializeComponent();
        }

        private void Login_button_Click(object sender, EventArgs e)
        {
            obj = new Controller();

            //Is the manager only responsible for changing the prices?
            Object password = obj.CheckPassword_Inventory(Convert.ToInt32(ID_textBox.Text));
            if (((string)password) == Password_textBox.Text)
            {
                Inventory n = new Inventory();
                n.Show();
            }
            else
            {
                MessageBox.Show("Password isn't correct, Please Try Again");
            }
        }
    }
}
