﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Hypermarket
{
    public partial class Update_Loyalty : Form
    {
        Controller controllerObj;
        int Cust_ID;
        public Update_Loyalty(Controller controllerObj, decimal Cust_ID)
        {
            InitializeComponent();
            this.Cust_ID = Int32.Parse(Cust_ID.ToString());
            this.controllerObj = controllerObj;
            CID.Text = Cust_ID.ToString();
        }

        private void Update_LP_Click(object sender, EventArgs e)
        {
            controllerObj.UpdateLoyaltyP(Cust_ID, LP.Value);
            MessageBox.Show("Loalty Points Updated Successfully!");
        }

        private void Update_Loyalty_Load(object sender, EventArgs e)
        {

        }
    }
}
