﻿namespace Hypermarket
{
    partial class New_Customer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.ID = new System.Windows.Forms.NumericUpDown();
            this.Age = new System.Windows.Forms.NumericUpDown();
            this.ApNum = new System.Windows.Forms.NumericUpDown();
            this.FName = new System.Windows.Forms.TextBox();
            this.LName = new System.Windows.Forms.TextBox();
            this.PhoneNumber = new System.Windows.Forms.TextBox();
            this.Email = new System.Windows.Forms.TextBox();
            this.Gender = new System.Windows.Forms.ComboBox();
            this.Street = new System.Windows.Forms.TextBox();
            this.City = new System.Windows.Forms.TextBox();
            this.Insert_Customer = new System.Windows.Forms.Button();
            this.BNum = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.ID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Age)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ApNum)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(18, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(123, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "First Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(232, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Last Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(325, 19);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Phone Number";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(446, 19);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "E-mail";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(39, 89);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Gender";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(123, 89);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(26, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Age";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(190, 89);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Street";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(386, 89);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(95, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "Apartment Number";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(508, 89);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(24, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "City";
            // 
            // ID
            // 
            this.ID.Location = new System.Drawing.Point(28, 50);
            this.ID.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.ID.Name = "ID";
            this.ID.Size = new System.Drawing.Size(53, 20);
            this.ID.TabIndex = 10;
            this.ID.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // Age
            // 
            this.Age.Location = new System.Drawing.Point(116, 121);
            this.Age.Minimum = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.Age.Name = "Age";
            this.Age.Size = new System.Drawing.Size(46, 20);
            this.Age.TabIndex = 11;
            this.Age.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // ApNum
            // 
            this.ApNum.Location = new System.Drawing.Point(390, 121);
            this.ApNum.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.ApNum.Name = "ApNum";
            this.ApNum.Size = new System.Drawing.Size(75, 20);
            this.ApNum.TabIndex = 12;
            this.ApNum.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // FName
            // 
            this.FName.Location = new System.Drawing.Point(126, 50);
            this.FName.Name = "FName";
            this.FName.Size = new System.Drawing.Size(76, 20);
            this.FName.TabIndex = 13;
            // 
            // LName
            // 
            this.LName.Location = new System.Drawing.Point(235, 49);
            this.LName.Name = "LName";
            this.LName.Size = new System.Drawing.Size(76, 20);
            this.LName.TabIndex = 14;
            // 
            // PhoneNumber
            // 
            this.PhoneNumber.Location = new System.Drawing.Point(327, 50);
            this.PhoneNumber.Name = "PhoneNumber";
            this.PhoneNumber.Size = new System.Drawing.Size(93, 20);
            this.PhoneNumber.TabIndex = 15;
            // 
            // Email
            // 
            this.Email.Location = new System.Drawing.Point(449, 49);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(138, 20);
            this.Email.TabIndex = 16;
            // 
            // Gender
            // 
            this.Gender.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.Gender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.Gender.Location = new System.Drawing.Point(28, 121);
            this.Gender.Name = "Gender";
            this.Gender.Size = new System.Drawing.Size(53, 21);
            this.Gender.TabIndex = 17;
            // 
            // Street
            // 
            this.Street.Location = new System.Drawing.Point(193, 122);
            this.Street.Name = "Street";
            this.Street.Size = new System.Drawing.Size(76, 20);
            this.Street.TabIndex = 18;
            // 
            // City
            // 
            this.City.Location = new System.Drawing.Point(511, 122);
            this.City.Name = "City";
            this.City.Size = new System.Drawing.Size(76, 20);
            this.City.TabIndex = 19;
            // 
            // Insert_Customer
            // 
            this.Insert_Customer.Location = new System.Drawing.Point(235, 173);
            this.Insert_Customer.Name = "Insert_Customer";
            this.Insert_Customer.Size = new System.Drawing.Size(160, 46);
            this.Insert_Customer.TabIndex = 20;
            this.Insert_Customer.Text = "Insert Customer";
            this.Insert_Customer.UseVisualStyleBackColor = true;
            this.Insert_Customer.Click += new System.EventHandler(this.Insert_Customer_Click);
            // 
            // BNum
            // 
            this.BNum.Location = new System.Drawing.Point(291, 122);
            this.BNum.Name = "BNum";
            this.BNum.Size = new System.Drawing.Size(76, 20);
            this.BNum.TabIndex = 22;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(283, 87);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(84, 13);
            this.label11.TabIndex = 21;
            this.label11.Text = "Building Number";
            // 
            // New_Customer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(636, 273);
            this.Controls.Add(this.BNum);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.Insert_Customer);
            this.Controls.Add(this.City);
            this.Controls.Add(this.Street);
            this.Controls.Add(this.Gender);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.PhoneNumber);
            this.Controls.Add(this.LName);
            this.Controls.Add(this.FName);
            this.Controls.Add(this.ApNum);
            this.Controls.Add(this.Age);
            this.Controls.Add(this.ID);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "New_Customer";
            this.Text = "New Customer";
            this.Load += new System.EventHandler(this.New_Customer_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Age)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ApNum)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown ID;
        private System.Windows.Forms.NumericUpDown Age;
        private System.Windows.Forms.NumericUpDown ApNum;
        private System.Windows.Forms.TextBox FName;
        private System.Windows.Forms.TextBox LName;
        private System.Windows.Forms.TextBox PhoneNumber;
        private System.Windows.Forms.TextBox Email;
        private System.Windows.Forms.ComboBox Gender;
        private System.Windows.Forms.TextBox Street;
        private System.Windows.Forms.TextBox City;
        private System.Windows.Forms.Button Insert_Customer;
        private System.Windows.Forms.TextBox BNum;
        private System.Windows.Forms.Label label11;
    }
}