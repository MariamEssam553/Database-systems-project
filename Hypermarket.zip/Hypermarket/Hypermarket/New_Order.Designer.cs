﻿namespace Hypermarket
{
    partial class New_Order
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.N_Items = new System.Windows.Forms.NumericUpDown();
            this.P_ID = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Add = new System.Windows.Forms.Button();
            this.Receipt = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.Total_Price = new System.Windows.Forms.TextBox();
            this.Remove = new System.Windows.Forms.Button();
            this.Confirm = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.CID = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.N_Items)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.P_ID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Receipt)).BeginInit();
            this.SuspendLayout();
            // 
            // N_Items
            // 
            this.N_Items.Location = new System.Drawing.Point(216, 47);
            this.N_Items.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.N_Items.Name = "N_Items";
            this.N_Items.Size = new System.Drawing.Size(120, 20);
            this.N_Items.TabIndex = 8;
            this.N_Items.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // P_ID
            // 
            this.P_ID.Location = new System.Drawing.Point(40, 47);
            this.P_ID.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.P_ID.Name = "P_ID";
            this.P_ID.Size = new System.Drawing.Size(120, 20);
            this.P_ID.TabIndex = 7;
            this.P_ID.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(213, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Number of Items";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(40, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Product ID";
            // 
            // Add
            // 
            this.Add.Location = new System.Drawing.Point(40, 90);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(296, 33);
            this.Add.TabIndex = 9;
            this.Add.Text = "Add";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // Receipt
            // 
            this.Receipt.AllowUserToAddRows = false;
            this.Receipt.AllowUserToDeleteRows = false;
            this.Receipt.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Receipt.Location = new System.Drawing.Point(40, 129);
            this.Receipt.Name = "Receipt";
            this.Receipt.ReadOnly = true;
            this.Receipt.Size = new System.Drawing.Size(504, 142);
            this.Receipt.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(40, 297);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Total Price";
            // 
            // Total_Price
            // 
            this.Total_Price.Location = new System.Drawing.Point(40, 313);
            this.Total_Price.Name = "Total_Price";
            this.Total_Price.ReadOnly = true;
            this.Total_Price.Size = new System.Drawing.Size(100, 20);
            this.Total_Price.TabIndex = 12;
            // 
            // Remove
            // 
            this.Remove.Location = new System.Drawing.Point(353, 90);
            this.Remove.Name = "Remove";
            this.Remove.Size = new System.Drawing.Size(191, 33);
            this.Remove.TabIndex = 13;
            this.Remove.Text = "Remove Selected Item";
            this.Remove.UseVisualStyleBackColor = true;
            this.Remove.Click += new System.EventHandler(this.Remove_Click);
            // 
            // Confirm
            // 
            this.Confirm.Location = new System.Drawing.Point(353, 309);
            this.Confirm.Name = "Confirm";
            this.Confirm.Size = new System.Drawing.Size(191, 46);
            this.Confirm.TabIndex = 14;
            this.Confirm.Text = "Confirm Order";
            this.Confirm.UseVisualStyleBackColor = true;
            this.Confirm.Click += new System.EventHandler(this.Confirm_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(404, 31);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 13);
            this.label4.TabIndex = 15;
            this.label4.Text = "Customer ID";
            // 
            // CID
            // 
            this.CID.Enabled = false;
            this.CID.Location = new System.Drawing.Point(407, 47);
            this.CID.Name = "CID";
            this.CID.ReadOnly = true;
            this.CID.Size = new System.Drawing.Size(62, 20);
            this.CID.TabIndex = 16;
            // 
            // New_Order
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(590, 367);
            this.Controls.Add(this.CID);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Confirm);
            this.Controls.Add(this.Remove);
            this.Controls.Add(this.Total_Price);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Receipt);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.N_Items);
            this.Controls.Add(this.P_ID);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "New_Order";
            this.Text = "New Order";
            this.Load += new System.EventHandler(this.New_Order_Load);
            ((System.ComponentModel.ISupportInitialize)(this.N_Items)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.P_ID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Receipt)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown N_Items;
        private System.Windows.Forms.NumericUpDown P_ID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.DataGridView Receipt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Total_Price;
        private System.Windows.Forms.Button Remove;
        private System.Windows.Forms.Button Confirm;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox CID;
    }
}