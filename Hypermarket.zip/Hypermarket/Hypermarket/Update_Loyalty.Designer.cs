﻿namespace Hypermarket
{
    partial class Update_Loyalty
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Update_LP = new System.Windows.Forms.Button();
            this.LP = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.CID = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.LP)).BeginInit();
            this.SuspendLayout();
            // 
            // Update_LP
            // 
            this.Update_LP.Location = new System.Drawing.Point(89, 107);
            this.Update_LP.Name = "Update_LP";
            this.Update_LP.Size = new System.Drawing.Size(120, 41);
            this.Update_LP.TabIndex = 0;
            this.Update_LP.Text = "Update";
            this.Update_LP.UseVisualStyleBackColor = true;
            this.Update_LP.Click += new System.EventHandler(this.Update_LP_Click);
            // 
            // LP
            // 
            this.LP.Location = new System.Drawing.Point(133, 70);
            this.LP.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.LP.Name = "LP";
            this.LP.Size = new System.Drawing.Size(120, 20);
            this.LP.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Loyalty Points";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Customer_ID";
            // 
            // CID
            // 
            this.CID.Enabled = false;
            this.CID.Location = new System.Drawing.Point(133, 24);
            this.CID.Name = "CID";
            this.CID.Size = new System.Drawing.Size(120, 20);
            this.CID.TabIndex = 4;
            // 
            // Update_Loyalty
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(300, 160);
            this.Controls.Add(this.CID);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LP);
            this.Controls.Add(this.Update_LP);
            this.Name = "Update_Loyalty";
            this.Text = "Update Loyalty Points";
            this.Load += new System.EventHandler(this.Update_Loyalty_Load);
            ((System.ComponentModel.ISupportInitialize)(this.LP)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Update_LP;
        private System.Windows.Forms.NumericUpDown LP;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox CID;
    }
}