﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hypermarket
{
    public partial class Proc_Functionalities : Form
    {
        int i;
        Controller obj;
        public Proc_Functionalities(Object id)
        {
            InitializeComponent();
            i = ((int)id);
            obj = new Controller();
        }

        private void Proc_Functionalities_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            View_suppliers G = new View_suppliers();
            G.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Insert_Suppliers G = new Insert_Suppliers();
            G.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Insert_Product G = new Insert_Product();
            G.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            View_Products G = new View_Products();
            G.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Shipment G = new Shipment(i);
            G.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            DeleteProducts G = new DeleteProducts();
            G.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Supplier_stats G = new Supplier_stats();
            G.Show();
        }
    }
}
