﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hypermarket
{
    public partial class Welcome : Form
    {
        public Welcome()
        {
            InitializeComponent();
        }

        private void Welcome_Load(object sender, EventArgs e)
        {

        }

        private void proc_Click(object sender, EventArgs e)
        {
            Proc_Login G = new Proc_Login();
            G.Show();
        }

        private void cashier_Click(object sender, EventArgs e)
        {
            Cashier_Login G = new Cashier_Login();
            G.Show();
        }

        private void It_Click(object sender, EventArgs e)
        {
            it_login G = new it_login();
            G.Show();
        }

        private void Sales_Click(object sender, EventArgs e)
        {
            Sales_Login s = new Sales_Login();
            s.Show();
        }

        private void Inventory_Click(object sender, EventArgs e)
        {
            Inventory_logIn n = new Inventory_logIn();
            n.Show();
        }
    }
}
