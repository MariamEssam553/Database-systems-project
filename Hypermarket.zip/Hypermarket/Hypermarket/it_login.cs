﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hypermarket
{
    public partial class it_login : Form
    {
        Controller obj;
        public it_login()
        {
            InitializeComponent();
            obj = new Controller();
        }

        private void login_Click(object sender, EventArgs e)
        {
            if (fname.Text == "" || lname.Text == "" || password.Text == "")
            {
                return;
            }
            else
            {
                Object pass = obj.ItPass(fname.Text, lname.Text);
                if (((string)pass) == password.Text)
                {
                    Object id = obj.Procid(fname.Text, lname.Text);
                    Form1 I = new Form1();
                    I.Show();
                }
                else
                {
                    MessageBox.Show("Invalid credentials");
                }
            }
        }
    }
}
