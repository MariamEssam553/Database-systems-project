﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hypermarket
{
    public partial class Cashier_Login : Form
    {
        Controller obj;
        public Cashier_Login()
        {
            InitializeComponent();
            obj = new Controller();
        }

        private void Login_Click(object sender, EventArgs e)
        {
            if (fname.Text == "" || lname.Text == "" || Password.Text == "")
            {
                MessageBox.Show("Please Enter all Fields!");
                return;
            }
            else
            {
                Object password = obj.CashierPass(fname.Text, lname.Text);
                if (((string)password) == Password.Text)
                {
                    Object id = obj.Cashierid(fname.Text, lname.Text);
                    Cashier C = new Cashier(Int32.Parse(id.ToString()));
                    C.Show();
                }
                else
                {
                    MessageBox.Show("Invalid credentials!");
                }
            }
        }
    }
}
