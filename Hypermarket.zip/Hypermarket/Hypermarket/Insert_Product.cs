﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hypermarket
{
    public partial class Insert_Product : Form
    {
        Controller obj;
        public Insert_Product()
        {
            InitializeComponent();
            obj = new Controller();
            Category.DataSource = new string[] {"Electronics and appliances","Clothes","Beauty","Computer and networking","Gardening","Health","Music and Movies","Sport and Fitness","Groceries"};
        }

        private void Insert_Product_Load(object sender, EventArgs e)
        {

        }

        private void Category_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Category.SelectedIndex==0)
            {
                SubCategory.DataSource = new string[] {"Batteries","Phone","Televesion","Console"};
            }
            else
            {
                if (Category.SelectedIndex == 1)
                {
                    SubCategory.DataSource = new string[] { "Gloves", "Shirt", "T-Shirt", "Socks","Shoes" };
                }
                else
                {
                    if (Category.SelectedIndex == 2)
                    {
                        SubCategory.DataSource = new string[] { "Hair care", "Skin care", "wig", "Makeup"};
                    }
                    else
                    {
                        if (Category.SelectedIndex == 3)
                        {
                            SubCategory.DataSource = new string[] { "Laptop", "Printer", "Desktop computer", "Router" };
                        }
                        else
                        {
                            if (Category.SelectedIndex == 4)
                            {
                                SubCategory.DataSource = new string[] { "Barbeque tools", "Flowers", "Decoration", "Furniture" };
                            }
                            else
                            {
                                if (Category.SelectedIndex == 5)
                                {
                                    SubCategory.DataSource = new string[] { "Shaver", "Dental care", "Massagers", "Men grooming" };
                                }
                                else
                                {
                                    if (Category.SelectedIndex == 6)
                                    {
                                        SubCategory.DataSource = new string[] { "Instrument", "Movie", "Music Cds", "Series" };
                                    }
                                    else
                                    {
                                        if (Category.SelectedIndex == 8)
                                        {
                                            SubCategory.DataSource = new string[] { "baby food", "Dry food", "Soft drinks", "Fruits and vegetables" };
                                        }
                                        else
                                        {
                                            SubCategory.DataSource = new string[] { "Balls", "Bikes", "Protective gear", "Treadmills" };
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text=="" || Price.Text=="")
            {
                return;
            }
            int price;
            bool k = Int32.TryParse(Price.Text, out price);
            if (!k)
            {
                MessageBox.Show("Invalid Price");
                return;
            }
            else
            {
                if (price <= 0)
                {
                    MessageBox.Show("Invalid Price");
                    return;
                }
            }
            int id; 
            Int32.TryParse((numericUpDown1.Value).ToString(), out id);

            int r = obj.InsertProduct(id,price,textBox1.Text,Category.Text,SubCategory.Text);

            if (r==0)
            {
                MessageBox.Show("Insertion failed. Check that inputs are valid");
            }
            else
            {
                MessageBox.Show("Insertion Successful");
            }
        }
    }
}
