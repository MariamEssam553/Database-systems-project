﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Hypermarket
{
    public partial class Cashier : Form
    {
        int Cashier_ID;
        Controller controllerObj = new Controller();
        public Cashier(int Cashier_ID)
        {
            InitializeComponent();
            this.Cashier_ID = Cashier_ID;
        }

        private void New_Order(object sender, EventArgs e)
        {
            if (controllerObj.CustIDExist(Cust_ID.Value) == 0)
            {
                MessageBox.Show("Customer ID Not Found!");
                return;
            }
            New_Order NO = new New_Order(controllerObj, Cashier_ID, Cust_ID.Value);
            NO.Show();
        }
        private void Update_Loyalty_Click(object sender, EventArgs e)
        {
            if (controllerObj.CustIDExist(Cust_ID.Value) == 0)
                MessageBox.Show("ID Not Found!");
            else
            {
                Update_Loyalty LP = new Update_Loyalty(controllerObj, Cust_ID.Value);
                LP.Show();
            }
        }

        private void New_Customer_Click(object sender, EventArgs e)
        {
            New_Customer NC = new New_Customer(controllerObj);
            NC.Show();
        }

        private void CInfo_Click(object sender, EventArgs e)
        {
            if (controllerObj.CustIDExist(Cust_ID.Value) == 0)
                MessageBox.Show("Customer ID Not Found!");
            else
            {
                View_Customer VC = new View_Customer(controllerObj, Cust_ID.Value);
                VC.Show();
            }
        }
    }
}
