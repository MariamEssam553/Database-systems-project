﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hypermarket
{
    public partial class DeleteProducts : Form
    {
        Controller obj;
        public DeleteProducts()
        {
            InitializeComponent();
            obj = new Controller();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int p;
            bool k = Int32.TryParse(textBox1.Text, out p);
            if (k)
            {
                int r = obj.DeleteProd(p);
                if (r != 0)
                {
                    MessageBox.Show("Deletion Successful");
                }
                else
                {
                    MessageBox.Show("Deletion not Successful");
                }
            }
        }

        private void DeleteProducts_Load(object sender, EventArgs e)
        {

        }
    }
}
