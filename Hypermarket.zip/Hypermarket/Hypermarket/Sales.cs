﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hypermarket
{
    public partial class Sales : Form
    {
        Controller obj;
        public Sales()
        {
            InitializeComponent();
        }

        private void Update_button_Click(object sender, EventArgs e)
        {
            obj = new Controller();

            if (Code_textBox.Text == "" || Price_textBox.Text == "")
            {
                MessageBox.Show("Please enter the information of the desired product!");
            }

            int result = obj.UpdatePrice(Convert.ToInt32(Code_textBox.Text), Convert.ToInt32(Price_textBox.Text));

            if (result == 0)
            {
                MessageBox.Show("No price is updated! Please chech the product code");
            }
            else
            {
                MessageBox.Show("The product#" + Code_textBox.Text + "'s price is updated successfully");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            obj = new Controller();
            profit_label.Text = Convert.ToString(obj.single_profit(Convert.ToInt32(P_textBox.Text)));
        }

        private void Profit_button_Click(object sender, EventArgs e)
        {

            obj = new Controller();

            Profit_per_day p = new Profit_per_day();
            p.Show();

        }

        private void most_button_Click(object sender, EventArgs e)
        {
            obj = new Controller();
            SName.Text = Convert.ToString(obj.most_sold());
            LName.Text = Convert.ToString(obj.least_sold());
            //int most = obj.most_sold();
            //int least = obj.least_sold();
            //SName.Text = Convert.ToString(obj.get_name(most));
            //LName.Text = Convert.ToString(obj.get_name(least));
            dataGridView1.DataSource = obj.order();
            dataGridView1.Refresh();
        }
    }
}
