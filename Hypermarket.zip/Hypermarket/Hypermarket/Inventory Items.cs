﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hypermarket
{
    public partial class Inventory_Items : Form
    {
        Controller obj;
        public Inventory_Items()
        {
            InitializeComponent();
        }

        private void Inventory_Items_Load(object sender, EventArgs e)
        {
            obj = new Controller();
            dataGridView1.DataSource = obj.InventoryItems();
            dataGridView1.Refresh();
        }
    }
}
