﻿
namespace Hypermarket
{
    partial class Sales_Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ID_textBox = new System.Windows.Forms.TextBox();
            this.ID_label = new System.Windows.Forms.Label();
            this.Password_textBox = new System.Windows.Forms.TextBox();
            this.Password_label = new System.Windows.Forms.Label();
            this.Login_button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ID_textBox
            // 
            this.ID_textBox.Location = new System.Drawing.Point(272, 61);
            this.ID_textBox.Name = "ID_textBox";
            this.ID_textBox.Size = new System.Drawing.Size(141, 22);
            this.ID_textBox.TabIndex = 9;
         
            // 
            // ID_label
            // 
            this.ID_label.AutoSize = true;
            this.ID_label.Location = new System.Drawing.Point(113, 64);
            this.ID_label.Name = "ID_label";
            this.ID_label.Size = new System.Drawing.Size(59, 17);
            this.ID_label.TabIndex = 8;
            this.ID_label.Text = "Enter ID";
           
            // 
            // Password_textBox
            // 
            this.Password_textBox.Location = new System.Drawing.Point(272, 125);
            this.Password_textBox.Name = "Password_textBox";
            this.Password_textBox.Size = new System.Drawing.Size(141, 22);
            this.Password_textBox.TabIndex = 7;
            this.Password_textBox.UseSystemPasswordChar = true;
            
            // 
            // Password_label
            // 
            this.Password_label.AutoSize = true;
            this.Password_label.Location = new System.Drawing.Point(113, 128);
            this.Password_label.Name = "Password_label";
            this.Password_label.Size = new System.Drawing.Size(107, 17);
            this.Password_label.TabIndex = 6;
            this.Password_label.Text = "Enter Password";
           
            // 
            // Login_button
            // 
            this.Login_button.Location = new System.Drawing.Point(191, 218);
            this.Login_button.Name = "Login_button";
            this.Login_button.Size = new System.Drawing.Size(151, 33);
            this.Login_button.TabIndex = 5;
            this.Login_button.Text = "Login";
            this.Login_button.UseVisualStyleBackColor = true;
            this.Login_button.Click += new System.EventHandler(this.Login_button_Click);
            // 
            // Sales_Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(525, 318);
            this.Controls.Add(this.ID_textBox);
            this.Controls.Add(this.ID_label);
            this.Controls.Add(this.Password_textBox);
            this.Controls.Add(this.Password_label);
            this.Controls.Add(this.Login_button);
            this.Name = "Sales_Login";
            this.Text = "Sales_Login";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox ID_textBox;
        private System.Windows.Forms.Label ID_label;
        private System.Windows.Forms.TextBox Password_textBox;
        private System.Windows.Forms.Label Password_label;
        private System.Windows.Forms.Button Login_button;
    }
}