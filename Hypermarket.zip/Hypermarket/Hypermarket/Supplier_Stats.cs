﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hypermarket
{
    public partial class Supplier_stats : Form
    {
        Controller obj;
        public Supplier_stats()
        {
            InitializeComponent();
            obj = new Controller();
            dataGridView1.ReadOnly = true;
            textBox1.ReadOnly = true;
            Object num = obj.numbersupp();
            textBox1.Text = ((int)num).ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataTable dt = obj.selectcity();
            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DataTable dt = obj.selectshipments();
            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();
        }
    }
}
