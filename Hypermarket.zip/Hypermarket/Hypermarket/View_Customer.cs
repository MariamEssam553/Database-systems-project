﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Hypermarket
{
    public partial class View_Customer : Form
    {
        Controller controllerObj;
        int Cust_ID;
        public View_Customer(Controller controllerObj, decimal Cust_ID)
        {
            InitializeComponent();
            this.controllerObj = controllerObj;
            this.Cust_ID = Int32.Parse(Cust_ID.ToString());
            Cust_Info.DataSource = controllerObj.getCustomerInfo(this.Cust_ID);
            Cust_Info.Refresh();
        }

        private void View_Customer_Load(object sender, EventArgs e)
        {

        }
    }
}
