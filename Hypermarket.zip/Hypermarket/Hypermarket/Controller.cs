﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Windows.Forms;

namespace Hypermarket
{
    public class Controller
    {
        DBManager dbMan;
        public Controller()
        {
            dbMan = new DBManager();
        }

      
        public void TerminateConnection()
        {
            dbMan.CloseConnection();
        }

        public Object ProcPass(string Fname,string Lname)
        {
            string query = "Select password from [Procurement department] Where Fname = '" + Fname + "' AND Lname = '" + Lname + "';";
            return dbMan.ExecuteScalar(query);
        }
        public Object ItPass(string fname,string lname)
        {
            string query = "Select password from [it department] Where Fname = '" + fname + "' AND Lname = '" + lname + "';";
            return dbMan.ExecuteScalar(query);
        }

        public Object Procid(string Fname, string Lname)
        {
            string query = "Select ID from [Procurement department] Where Fname = '" + Fname + "' AND Lname = '" + Lname + "';";
            return dbMan.ExecuteScalar(query);
        }


        public DataTable GetSuppliers()
        {
            string query = "select * from Suppliers;";
            return dbMan.ExecuteReader(query);
        }

        public int InsertSupp(int id,string Fname,string Lname,int phone,string street,string building,string city)
        {
            string query = "Insert into Suppliers values ("+id+",'"+Fname+"','"+Lname+"',"+phone+",'"+street+"','"+building+"','"+city+"');";
            return dbMan.ExecuteNonQuery(query);
        }

        public DataTable GetProducts()
        {
            string query = "select * from Inventory;";
            return dbMan.ExecuteReader(query);
        }

        public int InsertProduct(int id,int price,string name,string category,string subc )
        {
            string query = "Insert into Inventory Values ("+id+","+price+",0,'"+name+"');";
            dbMan.ExecuteNonQuery(query);
            query = "Insert into Category Values("+id+",'"+category+"', '"+subc+"');";
            return dbMan.ExecuteNonQuery(query);
        }

        public int InsertShipment(int p,int e,int s,string date,int q)
        {
            string query = "insert into Supplies values("+p+", "+e+","+s+",'"+date+"',"+q+");";
            return dbMan.ExecuteNonQuery(query);
        }

        public int DeleteProd(int p)
        {
            string query = "delete from Inventory where P# = "+p+";";
            return dbMan.ExecuteNonQuery(query);
        }
        public Object CashierPass(string Fname, string Lname)
        {
            string query = "Select password from Cashiers Where Fname = '" + Fname + "' AND Lname = '" + Lname + "';";
            return dbMan.ExecuteScalar(query);
        }
        internal object Cashierid(string Fname, string Lname)
        {
            string query = "Select ID from Cashiers Where Fname = '" + Fname + "' " +
                "AND Lname = '" + Lname + "';";
            return dbMan.ExecuteScalar(query);
        }

        public int UpdateSales(String PID, String CustID, String CashID)
        {
            string query1 = "Select Quantity From For Sale Product Where P# = " + PID + ";";
            int q = Int32.Parse(dbMan.ExecuteScalar(query1).ToString());
            q--;
            string query2 = "Update For_Sale_Product" +
                "Set Quantity = " + q.ToString() +
                "Where P# =" + PID + ";";
            dbMan.ExecuteNonQuery(query2);
            q = q + 2;
            string query3 = "Insert Into Products_Bought (P#, Customer ID, Cashier ID, Quantity) " +
                "Values (" + PID + ", " + CashID + ", " + CustID + ", " + q.ToString() + ");";

            return dbMan.ExecuteNonQuery(query3);
        }

        internal int ItemExist(decimal P_ID)
        {
            string query = "SELECT P# FROM [For Sale Products] Where P# = " + P_ID.ToString() + ";";
            if (dbMan.ExecuteScalar(query) == null)
                return 0;
            return (int)dbMan.ExecuteScalar(query);
        }

        internal DataTable getItemInfo(decimal PNo)
        {
            string query = "Select F.P#, I.Name, F.Selling_price " +
                "From [For Sale Products] F Join Inventory I on " +
                "F.P# = I.P# Where F.P# = " + PNo.ToString() + ";";
            return dbMan.ExecuteReader(query);
        }

        internal void UpdateLoyaltyP(int cID, decimal lp)
        {
            string query = "EXEC UpdateLoyaltyPts @CID = " + cID.ToString() +
                ", @LP = " + lp.ToString() + ";";
            dbMan.ExecuteNonQuery(query);
        }

        public DataTable getCustomerInfo(int cust_ID)
        {
            string query = "Select * From Customer Where ID = " + cust_ID.ToString();
            return dbMan.ExecuteReader(query);
        }

        public int InsertCustomer(decimal ID, string FName, string LName, string PhoneN, string Email
            , string Gender, decimal Age, string Street, string BNum, decimal ApNum, string City)
        {
            string query = "Insert Into Customer " +
                  "Values (" + ID.ToString() + ", '" + FName + "', '" + LName + "', " + PhoneN + ", '" +
                   Email + "', '" + Gender + "', " + Age.ToString() + ", '" + Street + "', '" + BNum +
                   "', " + ApNum.ToString() + ", '" + City + "', 0);";
            return dbMan.ExecuteNonQuery(query);
        }

        internal void ApplyBuys(int cashier_ID, int cust_ID)
        {
            DateTime dt = DateTime.UtcNow.Date;
            string dts = dt.ToString("yyyy-MM-dd");
            string query = "EXEC ApplyBuys @CashID = " + cashier_ID.ToString() +
                ", @CustID = " + cust_ID.ToString() + ", @Date = '" + dts + "';";
            dbMan.ExecuteNonQuery(query);
        }

        internal void ApplyBought(string v1, int cust_ID, int cashier_ID, string v2)
        {
            string query1 = "Insert Into [Products Bought] " +
                "Values(" + v1 + ", " + cust_ID.ToString() + ", " +
                cashier_ID.ToString() + ", " +
                v2 + ");";
            dbMan.ExecuteNonQuery(query1);
            string query2 = "SELECT Quantity FROM [For Sale Products]" +
                " Where P# = " + v1 + ";";
            int oldQ = (int)dbMan.ExecuteScalar(query2);
            int newQ = oldQ - Int32.Parse(v2.ToString());
            string query3 = "Update [For Sale Products] " +
                "Set Quantity = " + newQ.ToString() + " Where " +
                "P# = " + v1;
            dbMan.ExecuteNonQuery(query3);
        }

        public int CustIDExist(decimal ID)
        {
            string query = "SELECT Count(ID) FROM Customer Where ID = " + ID.ToString() + ";";
            return (int)dbMan.ExecuteScalar(query);
        }

        public DataTable SelectEmpTypes(string dep)
        {
            string query = "select title AS Type,count(*) AS Number from \"" + dep + "\" GROUP BY title;";
            return dbMan.ExecuteReader(query);
        }


        public int InsertEmployee(string dep, int id, string fname, string lname, int phone, string email, int salary, string gender, string startDate = "", int age = 0, string street = "", string building = "", int appartment = 0, string city = "", string title = "", string password = "", int hours = 0)
        {
            string query = "INSERT INTO \"" + dep + "\" " +
                            "Values (" + id + ",'" + fname + "','" + lname + "'," + phone + ",'" + email + "'," + salary + ",'" + gender + "','" + startDate + "'," + age + ",'" + street + "','" + building + "'," + appartment + ",'" + city + "','" + title + "','" + password + "'," + hours + ");";
            return dbMan.ExecuteNonQuery(query);
        }

        public int UpdateEmployee(string dep, int id, int salary, int age, int hours)
        {
            string query = "UPDATE \"" + dep + "\" SET salary=" + salary + ", age=" + age + ", Working_hours=" + hours + " WHERE ID=" + id + " ;";
            return dbMan.ExecuteNonQuery(query);
        }

        public DataTable SelectEmpIds(string dep)
        {
            string query = "SELECT ID FROM \"" + dep + "\";";
            return dbMan.ExecuteReader(query);
        }
        public int DeleteEmp(string dep, int id)
        {
            string query = "DELETE FROM \"" + dep + "\" WHERE ID= " + id + " ;";
            return dbMan.ExecuteNonQuery(query);
        }


        public Object numbersupp()
        {
            string query = "select Count (ID) from Suppliers;";
            return dbMan.ExecuteScalar(query);
        }

        public DataTable selectcity()
        {
            string query = "select city,Count (city) AS value_occurrence from Suppliers group by city order by value_occurrence DESC; ";
            return dbMan.ExecuteReader(query);
        }

        public DataTable selectshipments()
        {
            string query = "select Supplier_ID,Count (Supplier_ID) AS value_occurrence from Supplies group by Supplier_ID order by value_occurrence DESC;";
            return dbMan.ExecuteReader(query);
        }



        /*-------------------------------------- #Sales Department#-------------------------------------------*/

        //Check the password for SalesLogin form 
        public Object CheckPassword_Sales(int id)
        {
            string query = "SELECT password FROM [Sales Department] WHERE ID = " + id + " ";

            return dbMan.ExecuteScalar(query);

        }

        //1-Modifies the info of present products. (as the price of the product) for Sales form
        public int UpdatePrice(int code, int newP)
        {
            string query = "UPDATE [For Sale Products] SET Selling_price= '" + newP + "' WHERE P# = '" + code + "'";
            return dbMan.ExecuteNonQuery(query);
        }

        //2-Orders a query to calculate the net profit of the hypermarket per day
        public int ProfitPerDay(string date)
        {
            //string query = "SELECT Quantity ,Profit, (SUM (Quantity*Profit)) AS total_profit " +
            //               "FROM [Profit per Product] ,( [Products Bought] JOIN Buys)  " +
            //               "WHERE A.Date = '" + date + "";

            //string query = "SELECT P# , Quantity FROM (Buys JOIN [Products Bought]) WHERE Date = '"+date+"' " +
            //    "GROUP BY P#";
            //string query1 = "SELECT P#, SUM(Quantity) FROM (Buys JOIN [Products Bought]) WHERE Date = '" + date + "' ";
            string query = "SELECT SUM([Profit]*[Quantity]) From [Profit per Product] , (Buys JOIN [Products Bought])" +
                           " Where P#.[Products Bought] = P#.Buys AND Date = " + (Convert.ToDateTime(date)).ToShortDateString() + "";
            int result = dbMan.ExecuteNonQuery(query);
            return result;
        }

        public int most_sold()
        {
            string query1 = "SELECT MAX(Quantity) FROM [Products Bought]";
            int max = Int32.Parse(dbMan.ExecuteScalar(query1).ToString());
            string query = "SELECT P# FROM [Products Bought] " +
                "WHERE Quantity = '" + max + " '";
            return dbMan.ExecuteNonQuery(query);
        }

        public int least_sold()
        {
            string query1 = "SELECT MIN(Quantity) FROM [Products Bought]";
            int min = Int32.Parse(dbMan.ExecuteScalar(query1).ToString());
            string query = "SELECT P# FROM [Products Bought] " +
                "WHERE Quantity =' " + min + " '";
            return dbMan.ExecuteNonQuery(query);
        }

        public Object get_name(int p)
        {
            string query = "SELECT Name FROM Inventory WHERE P# = '" + p + "'";
            return dbMan.ExecuteScalar(query);
        }

        public DataTable order()
        {
            string query = "SELECT P# , Quantity FROM [Products Bought] " +
                " ORDER BY Quantity ";
            //string query = "FROM [Products Bought] AS A "+
            //    "ORDERBY A.Quantity"+
            //  "SELECT P# , A.Quantity";
            return dbMan.ExecuteReader(query);
        }

        public int single_profit(int p)
        {
            string query1 = "SELECT Cost_price FROM  Inventory WHERE P#='" + p + "' ";
            string query2 = "SELECT Quantity FROM [For Sale Products] WHERE P#='" + p + "'";
            string query3 = "SELECT Selling_price FROM [For Sale Products] WHERE P#='" + p + "'";
            return (dbMan.ExecuteNonQuery(query1) - (dbMan.ExecuteNonQuery(query2) * dbMan.ExecuteNonQuery(query3)));
        }

        /*-------------------------------------- #Inventory Department#-------------------------------------------*/
        public Object CheckPassword_Inventory(int id)
        {
            string query = "SELECT password FROM [Inventory Department] WHERE ID = '" + id + "'";

            return dbMan.ExecuteScalar(query);
        }

        public DataTable InventoryItems()
        {
            string query = "SELECT * FROM Inventory";
            return dbMan.ExecuteReader(query);
        }

        public int Delete_inventory(int n, int p)
        {
            string query1 = "SELECT Quantity FROM Inventory WHERE P#='" + p + "' ";
            int result = Int32.Parse(dbMan.ExecuteScalar(query1).ToString());
            result = result - n;
            string query2 = "UPDATE Inventory SET Quantity = " + result + " WHERE P#=" + p + " ";

            return dbMan.ExecuteNonQuery(query2);
        }

        public int Add_inventory(int n, int p)
        {
            string query1 = "SELECT Quantity FROM Inventory WHERE P#='" + p + "' ";
            int result = Int32.Parse(dbMan.ExecuteScalar(query1).ToString());
            result = result + n;
            string query2 = "UPDATE Inventory SET Quantity = " + result + " WHERE P#=" + p + " ";

            return dbMan.ExecuteNonQuery(query2);
        }

        public void update_replenish(int p, int q, int id)
        {
            DateTime d = DateTime.Today;
            string query = "INSERT INTO Replenish (P#,Employee_ID,Date, Quantity)" +
                           "VALUES(" + p + "," + id + ",'" + d.Date.ToShortDateString() + "','" + q + "')";
            //"WHERE P#="+p+" AND ID = "+id+" ";
            dbMan.ExecuteNonQuery(query);
        }
        public DataTable ReplenishUpdate()
        {
            string query = "SELECT * FROM Replenish";
            return dbMan.ExecuteReader(query);
        }
    }
}
