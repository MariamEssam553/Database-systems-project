﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hypermarket
{
    public partial class Shipment : Form
    {
        int i;
        Controller obj;
        public Shipment(int x)
        {
            InitializeComponent();
            i = x;
            obj = new Controller();
        }

        private void Shipment_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Pnum.Text=="" || Supplier.Text=="" || Quantity.Text=="")
            {
                return;
            }

            DateTime dateTime = DateTime.UtcNow.Date;
            int p, s, q;
            bool b = Int32.TryParse(Pnum.Text, out p);
            bool t = Int32.TryParse(Supplier.Text, out s);
            bool w = Int32.TryParse(Quantity.Text, out q);

            if (b && t && w)
            {
                int r = obj.InsertShipment(p, i, s, dateTime.ToString("yyyy-MM-dd"), q);
                if (r==0)
                {
                    MessageBox.Show("Insertion valid make sure inputs are valid");
                    return;
                }
                else
                {
                    MessageBox.Show("Insertion Successful");
                }
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
