﻿namespace Hypermarket
{
    partial class View_Customer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Cust_Info = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.Cust_Info)).BeginInit();
            this.SuspendLayout();
            // 
            // Cust_Info
            // 
            this.Cust_Info.AllowUserToAddRows = false;
            this.Cust_Info.AllowUserToDeleteRows = false;
            this.Cust_Info.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Cust_Info.Location = new System.Drawing.Point(12, 12);
            this.Cust_Info.Name = "Cust_Info";
            this.Cust_Info.ReadOnly = true;
            this.Cust_Info.Size = new System.Drawing.Size(652, 101);
            this.Cust_Info.TabIndex = 0;
            // 
            // View_Customer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(676, 125);
            this.Controls.Add(this.Cust_Info);
            this.Name = "View_Customer";
            this.Text = "View Customer";
            this.Load += new System.EventHandler(this.View_Customer_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Cust_Info)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView Cust_Info;
    }
}