﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hypermarket
{
    public partial class Insert_Suppliers : Form
    {
        Controller obj;
        public Insert_Suppliers()
        {
            InitializeComponent();
            obj = new Controller();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           if (Fname.Text=="" || Lname.Text == "" || Phone.Text == "" || Street.Text == "" || Building.Text == "" || City.Text == "")
           {
                return;
           }
           else
           {
                int id = Int32.Parse(((numericUpDown1.Value).ToString()));
                int Pnumber;
                bool k = Int32.TryParse(Phone.Text, out Pnumber);
                if (k==true)
                {
                    int r = obj.InsertSupp(id, Fname.Text, Lname.Text, Pnumber , Street.Text, Building.Text, City.Text);
                    if (r==0)
                    {
                        MessageBox.Show("Insertion failed due to invalid inputs, check if id is available");
                    }
                    else
                    {
                        MessageBox.Show("Insertion of new supplier successful");
                    }
                }
                else
                {
                    MessageBox.Show("Invalid Phone number");
                }
           }
        }
    }
}
