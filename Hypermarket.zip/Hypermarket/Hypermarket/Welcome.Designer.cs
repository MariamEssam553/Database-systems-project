﻿
namespace Hypermarket
{
    partial class Welcome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.It = new System.Windows.Forms.Button();
            this.Sales = new System.Windows.Forms.Button();
            this.Inventory = new System.Windows.Forms.Button();
            this.cashier = new System.Windows.Forms.Button();
            this.proc = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.label1.Location = new System.Drawing.Point(379, 25);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(277, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Choose your department";
            // 
            // It
            // 
            this.It.Location = new System.Drawing.Point(97, 113);
            this.It.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.It.Name = "It";
            this.It.Size = new System.Drawing.Size(203, 28);
            this.It.TabIndex = 1;
            this.It.Text = "It Department";
            this.It.UseVisualStyleBackColor = true;
            this.It.Click += new System.EventHandler(this.It_Click);
            // 
            // Sales
            // 
            this.Sales.Location = new System.Drawing.Point(97, 226);
            this.Sales.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Sales.Name = "Sales";
            this.Sales.Size = new System.Drawing.Size(203, 28);
            this.Sales.TabIndex = 2;
            this.Sales.Text = "Sales Department";
            this.Sales.UseVisualStyleBackColor = true;
            this.Sales.Click += new System.EventHandler(this.Sales_Click);
            // 
            // Inventory
            // 
            this.Inventory.Location = new System.Drawing.Point(720, 113);
            this.Inventory.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Inventory.Name = "Inventory";
            this.Inventory.Size = new System.Drawing.Size(185, 28);
            this.Inventory.TabIndex = 3;
            this.Inventory.Text = "Inventory department";
            this.Inventory.UseVisualStyleBackColor = true;
            this.Inventory.Click += new System.EventHandler(this.Inventory_Click);
            // 
            // cashier
            // 
            this.cashier.Location = new System.Drawing.Point(720, 226);
            this.cashier.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cashier.Name = "cashier";
            this.cashier.Size = new System.Drawing.Size(185, 28);
            this.cashier.TabIndex = 4;
            this.cashier.Text = "Cashier";
            this.cashier.UseVisualStyleBackColor = true;
            this.cashier.Click += new System.EventHandler(this.cashier_Click);
            // 
            // proc
            // 
            this.proc.Location = new System.Drawing.Point(441, 170);
            this.proc.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.proc.Name = "proc";
            this.proc.Size = new System.Drawing.Size(188, 33);
            this.proc.TabIndex = 5;
            this.proc.Text = "Procurement Department";
            this.proc.UseVisualStyleBackColor = true;
            this.proc.Click += new System.EventHandler(this.proc_Click);
            // 
            // Welcome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.proc);
            this.Controls.Add(this.cashier);
            this.Controls.Add(this.Inventory);
            this.Controls.Add(this.Sales);
            this.Controls.Add(this.It);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Welcome";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Welcome_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button It;
        private System.Windows.Forms.Button Sales;
        private System.Windows.Forms.Button Inventory;
        private System.Windows.Forms.Button cashier;
        private System.Windows.Forms.Button proc;
    }
}

