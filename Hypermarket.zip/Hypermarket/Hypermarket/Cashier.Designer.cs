﻿namespace Hypermarket
{
    partial class Cashier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Update_Sales = new System.Windows.Forms.Button();
            this.New_Customer = new System.Windows.Forms.Button();
            this.Update_Loyalty = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Cust_ID = new System.Windows.Forms.NumericUpDown();
            this.CInfo = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Cust_ID)).BeginInit();
            this.SuspendLayout();
            // 
            // Update_Sales
            // 
            this.Update_Sales.Location = new System.Drawing.Point(30, 51);
            this.Update_Sales.Name = "Update_Sales";
            this.Update_Sales.Size = new System.Drawing.Size(151, 33);
            this.Update_Sales.TabIndex = 0;
            this.Update_Sales.Text = "New Order";
            this.Update_Sales.UseVisualStyleBackColor = true;
            this.Update_Sales.Click += new System.EventHandler(this.New_Order);
            // 
            // New_Customer
            // 
            this.New_Customer.Location = new System.Drawing.Point(450, 51);
            this.New_Customer.Name = "New_Customer";
            this.New_Customer.Size = new System.Drawing.Size(121, 33);
            this.New_Customer.TabIndex = 1;
            this.New_Customer.Text = "Insert New Customer";
            this.New_Customer.UseVisualStyleBackColor = true;
            this.New_Customer.Click += new System.EventHandler(this.New_Customer_Click);
            // 
            // Update_Loyalty
            // 
            this.Update_Loyalty.Location = new System.Drawing.Point(187, 51);
            this.Update_Loyalty.Name = "Update_Loyalty";
            this.Update_Loyalty.Size = new System.Drawing.Size(134, 33);
            this.Update_Loyalty.TabIndex = 2;
            this.Update_Loyalty.Text = "Update Loyalty Points";
            this.Update_Loyalty.UseVisualStyleBackColor = true;
            this.Update_Loyalty.Click += new System.EventHandler(this.Update_Loyalty_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(67, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Customer ID";
            // 
            // Cust_ID
            // 
            this.Cust_ID.Location = new System.Drawing.Point(187, 13);
            this.Cust_ID.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.Cust_ID.Name = "Cust_ID";
            this.Cust_ID.Size = new System.Drawing.Size(120, 20);
            this.Cust_ID.TabIndex = 4;
            this.Cust_ID.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // CInfo
            // 
            this.CInfo.Location = new System.Drawing.Point(30, 108);
            this.CInfo.Name = "CInfo";
            this.CInfo.Size = new System.Drawing.Size(291, 40);
            this.CInfo.TabIndex = 5;
            this.CInfo.Text = "View Customer Information";
            this.CInfo.UseVisualStyleBackColor = true;
            this.CInfo.Click += new System.EventHandler(this.CInfo_Click);
            // 
            // Cashier
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(653, 317);
            this.Controls.Add(this.CInfo);
            this.Controls.Add(this.Cust_ID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Update_Loyalty);
            this.Controls.Add(this.New_Customer);
            this.Controls.Add(this.Update_Sales);
            this.Name = "Cashier";
            this.Text = "Cashier";
            ((System.ComponentModel.ISupportInitialize)(this.Cust_ID)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Update_Sales;
        private System.Windows.Forms.Button New_Customer;
        private System.Windows.Forms.Button Update_Loyalty;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown Cust_ID;
        private System.Windows.Forms.Button CInfo;
    }
}