﻿
namespace Hypermarket
{
    partial class Inventory_logIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ID_textBox = new System.Windows.Forms.TextBox();
            this.ID_label = new System.Windows.Forms.Label();
            this.Password_textBox = new System.Windows.Forms.TextBox();
            this.Password_label = new System.Windows.Forms.Label();
            this.Login_button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ID_textBox
            // 
            this.ID_textBox.Location = new System.Drawing.Point(260, 82);
            this.ID_textBox.Name = "ID_textBox";
            this.ID_textBox.Size = new System.Drawing.Size(141, 22);
            this.ID_textBox.TabIndex = 14;
            // 
            // ID_label
            // 
            this.ID_label.AutoSize = true;
            this.ID_label.Location = new System.Drawing.Point(101, 85);
            this.ID_label.Name = "ID_label";
            this.ID_label.Size = new System.Drawing.Size(59, 17);
            this.ID_label.TabIndex = 13;
            this.ID_label.Text = "Enter ID";
            // 
            // Password_textBox
            // 
            this.Password_textBox.Location = new System.Drawing.Point(260, 146);
            this.Password_textBox.Name = "Password_textBox";
            this.Password_textBox.Size = new System.Drawing.Size(141, 22);
            this.Password_textBox.TabIndex = 12;
            this.Password_textBox.UseSystemPasswordChar = true;
            // 
            // Password_label
            // 
            this.Password_label.AutoSize = true;
            this.Password_label.Location = new System.Drawing.Point(101, 149);
            this.Password_label.Name = "Password_label";
            this.Password_label.Size = new System.Drawing.Size(107, 17);
            this.Password_label.TabIndex = 11;
            this.Password_label.Text = "Enter Password";
            // 
            // Login_button
            // 
            this.Login_button.Location = new System.Drawing.Point(179, 239);
            this.Login_button.Name = "Login_button";
            this.Login_button.Size = new System.Drawing.Size(151, 33);
            this.Login_button.TabIndex = 10;
            this.Login_button.Text = "Login";
            this.Login_button.UseVisualStyleBackColor = true;
            this.Login_button.Click += new System.EventHandler(this.Login_button_Click);
            // 
            // Inventory_logIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(503, 355);
            this.Controls.Add(this.ID_textBox);
            this.Controls.Add(this.ID_label);
            this.Controls.Add(this.Password_textBox);
            this.Controls.Add(this.Password_label);
            this.Controls.Add(this.Login_button);
            this.Name = "Inventory_logIn";
            this.Text = "Inventory_logIn";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox ID_textBox;
        private System.Windows.Forms.Label ID_label;
        private System.Windows.Forms.TextBox Password_textBox;
        private System.Windows.Forms.Label Password_label;
        private System.Windows.Forms.Button Login_button;
    }
}