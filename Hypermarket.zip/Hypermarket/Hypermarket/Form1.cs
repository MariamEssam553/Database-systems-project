﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hypermarket
{
    public partial class Form1 : Form
    {
        Controller controllerObj;
        public Form1()
        {
            InitializeComponent();
            controllerObj = new Controller();
            DataTable dt = controllerObj.SelectEmpIds(comboBox2.Text);
            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "ID";
        }

        private void viewEmpTypes_Click(object sender, EventArgs e)
        {
            DataTable dt = controllerObj.SelectEmpTypes(comboBox2.Text);
            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();
        }

        private void insertEmployee_Click(object sender, EventArgs e)
        {
            String s = "";
            StringBuilder err = new StringBuilder();
            err.Append(s);
            Object data1 = ValidationClass.isPositiveInteger(empId.Text, err);
            Object data2 = ValidationClass.isPositiveInteger(empPhone.Text, err);
            Object data3 = ValidationClass.isPositiveInteger(empSalary.Text, err);
            Object data4 = ValidationClass.isPositiveInteger(empAge.Text, err);
            Object data5 = ValidationClass.isPositiveInteger(empAppartment.Text, err);
            Object data6 = ValidationClass.isPositiveInteger(empHours.Text, err);
            if (data1==null || data2 == null || data3 == null || data4 == null)
            {
                MessageBox.Show(err.ToString());
            }
            else
            {
                int res1= (int)data1;
                int res2 = (int)data2;
                int res3 = (int)data3;
                int res4 = (int)data4;
                int res5 = (int)data5;
                int res6 = (int)data6;

                int query = controllerObj.InsertEmployee(comboBox2.Text,res1, empFname.Text, empLname.Text,res2,empEmail.Text,res3,empGender.Text,empStartDate.Text,res4,empStreet.Text,empBuilding.Text,res5,empCity.Text,empTitle.Text,empPassword.Text,res6);
                if (query == 0)
                {
                    MessageBox.Show("The insertion of a new Employee failed");
                }
                else
                {
                    MessageBox.Show("The row is inserted successfully!");
                }
            }
        }

        private void updateEmp_Click(object sender, EventArgs e)
        {
            String s = "";
            StringBuilder err = new StringBuilder();
            err.Append(s);
            Object data1 = ValidationClass.isPositiveInteger(updSalary.Text, err);
            Object data2 = ValidationClass.isPositiveInteger(updAge.Text, err);
            Object data3 = ValidationClass.isPositiveInteger(updHours.Text, err);
            if (data1 == null || data2 == null || data3 == null)
            {
                MessageBox.Show(err.ToString());
            }
            else
            {
                int res1 = (int)data1;
                int res2 = (int)data2;
                int res3 = (int)data3;
                int query = controllerObj.UpdateEmployee(comboBox2.Text,Int32.Parse(comboBox1.Text),res1,  res2,res3);
                if (query == 0)
                {
                    MessageBox.Show("The Update of Employee failed");
                }
                else
                {
                    MessageBox.Show("The row is inserted successfully!");
                }
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int query = controllerObj.DeleteEmp(comboBox2.Text,Int32.Parse(comboBox1.Text));
            if (query == 0)
            {
                MessageBox.Show("Deletion of Employee failed");
            }
            else
            {
                MessageBox.Show("The row is deleted successfully!");
            }
        }

        private void refresh_Click(object sender, EventArgs e)
        {
            DataTable dt = controllerObj.SelectEmpIds(comboBox2.Text);
            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "ID";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
