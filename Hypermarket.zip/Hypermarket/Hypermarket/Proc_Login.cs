﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hypermarket
{
    public partial class Proc_Login : Form
    {
        Controller obj;
        
        public Proc_Login()
        {
            InitializeComponent();
            obj = new Controller();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (fname.Text==""|| lname.Text=="" || pass.Text=="")
            {
                return;
            }
            else
            {
                Object password = obj.ProcPass(fname.Text, lname.Text);
                if (((string)password)==pass.Text)
                {
                    Object id = obj.Procid(fname.Text, lname.Text);
                    Proc_Functionalities G = new Proc_Functionalities(id);
                    G.Show();
                }
                else
                {
                    MessageBox.Show("Invalid credentials");
                }
            }
        }

        private void Proc_Login_Load(object sender, EventArgs e)
        {

        }
    }
}
